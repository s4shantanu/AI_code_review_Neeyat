# test_project/hello.py
def badCode():print("badly formatted")

badCode()
